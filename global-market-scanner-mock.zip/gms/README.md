# Global Market Scanner (Mock Mode) — Phone-first Play Internal Sharing

This is a **mock/demo** build that opens directly to Scanner (skip login). It is intended to generate an **Android App Bundle (AAB)** for Google Play **Internal App Sharing**.

## Run locally (optional)

```bash
npm install
npm run dev
```

## Build web

```bash
npm run build
```

## Capacitor (Android)

```bash
npm run cap:init
npm run cap:add-android
npm run cap:sync
```

## Notes
- Package name: `com.premiumscanner.app`
- Monetization (next release): weekly subscription with 3-day free trial.
