import React, { useMemo, useState } from 'react'
import { mockAssets } from './mock/assets'
import ChartPanel from './components/ChartPanel'

const TIMEFRAMES = ['1m', '5m', '15m', '1H', '1D']

export default function App() {
  const [market, setMarket] = useState('NSE')
  const [strategy, setStrategy] = useState('Breakout')
  const [betaMin, setBetaMin] = useState('')
  const [tf, setTf] = useState('5m')

  const [selected, setSelected] = useState(null)
  const [tab, setTab] = useState('Chart')

  const filtered = useMemo(() => {
    const min = betaMin ? Number(betaMin) : null
    return mockAssets.filter(a => (min == null ? true : a.beta >= min))
  }, [betaMin])

  return (
    <div className="container">
      <div className="header">
        <div className="brand">
          <div className="logo">G</div>
          <div>
            <div className="title">Global Market Scanner</div>
            <div className="subtitle">Mock Mode • Skip Login • Premium Dark + Gold</div>
          </div>
        </div>
        <div className="pills">
          <div className="pill"><strong>Plan:</strong> Guest</div>
          <div className="pill"><strong>Signal TF:</strong> {tf}</div>
          <div className="pill"><strong>Market:</strong> {market}</div>
        </div>
      </div>

      <div className="grid">
        <div className="card">
          <h3 className="sectionTitle">Filters</h3>
          <div className="controls">
            <div className="control">
              <label>Market</label>
              <select value={market} onChange={e => setMarket(e.target.value)}>
                <option value="NSE">NSE</option>
                <option value="MCX">MCX</option>
                <option value="NASDAQ">NASDAQ</option>
              </select>
            </div>
            <div className="control">
              <label>Strategy</label>
              <select value={strategy} onChange={e => setStrategy(e.target.value)}>
                <option>Breakout</option>
                <option>Breakdown</option>
                <option>ORB</option>
                <option>VWAP Reclaim</option>
              </select>
            </div>
            <div className="control">
              <label>Beta min</label>
              <input value={betaMin} onChange={e => setBetaMin(e.target.value)} placeholder="e.g. 1.2" />
            </div>
            <div className="control">
              <label>Mode</label>
              <select value="mock" disabled>
                <option value="mock">Mock (no API)</option>
              </select>
            </div>
          </div>

          <div className="timeframes">
            {TIMEFRAMES.map(x => (
              <button key={x} className={"tf " + (tf === x ? 'active' : '')} onClick={() => setTf(x)}>
                {x}
              </button>
            ))}
          </div>

          <div className="footerNote">
            Tip: Tap any stock to open chart + options + quarterly results.
          </div>
        </div>

        <div className="card">
          <h3 className="sectionTitle">Scanner Results</h3>
          <div className="table">
            {filtered.map(a => {
              const isBull = a.signal.direction === 'BULL'
              return (
                <div key={a.key} className="row" onClick={() => { setSelected(a); setTab('Chart') }}>
                  <div className="rowLeft">
                    <div className="sym">{a.symbol}</div>
                    <div className="name">{a.name}</div>
                    <div className="meta">
                      <div className="badge">Beta <strong>{a.beta.toFixed(2)}</strong></div>
                      <div className="badge">TF <strong>{tf}</strong></div>
                      <div className="badge">Confidence <strong>{a.signal.confidence}/100</strong></div>
                    </div>
                    <div className={"tag " + (isBull ? 'bull' : 'bear')}>
                      {isBull ? 'Bullish ' : 'Bearish '}{a.signal.label}
                    </div>
                  </div>
                  <div className="signal">
                    <div className="price">{a.price.toFixed(2)}</div>
                    <div className="change" style={{ color: a.changePct >= 0 ? '#2AE38E' : '#FF4D6D' }}>
                      {a.changePct >= 0 ? '+' : ''}{a.changePct.toFixed(2)}%
                    </div>
                  </div>
                </div>
              )
            })}
          </div>

          <div className="footerNote">
            Upgrade plan (next release): ₹199/day equivalent billed weekly + 3‑day free trial.
          </div>
        </div>
      </div>

      {selected && (
        <div className="modalBackdrop" onClick={() => setSelected(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modalHeader">
              <h3>{selected.symbol} • {selected.signal.direction === 'BULL' ? 'Bullish' : 'Bearish'} {selected.signal.label} • TF {tf}</h3>
              <button className="closeBtn" onClick={() => setSelected(null)}>Close</button>
            </div>

            <div className="tabs">
              {['Chart', 'Technicals', 'Options', 'Quarterly Results', 'Custom Indicator Request'].map(t => (
                <button key={t} className={"tab " + (tab === t ? 'active' : '')} onClick={() => setTab(t)}>
                  {t}
                </button>
              ))}
            </div>

            <div className="modalBody">
              {tab === 'Chart' && (
                <>
                  <ChartPanel seedPrice={selected.price} />
                  <div className="chips">
                    {selected.signal.reasons.map(r => <span key={r} className="chip">{r}</span>)}
                  </div>
                  <div className="kpiGrid">
                    <div className="kpi"><div className="k">Beta</div><div className="v">{selected.beta.toFixed(2)}</div></div>
                    <div className="kpi"><div className="k">Confidence</div><div className="v">{selected.signal.confidence}/100</div></div>
                    <div className="kpi"><div className="k">Market</div><div className="v">{market}</div></div>
                    <div className="kpi"><div className="k">Timeframe</div><div className="v">{tf}</div></div>
                  </div>
                </>
              )}

              {tab === 'Technicals' && (
                <div className="small">
                  This is Mock mode. Next-level strategies to add:
                  ORB, VWAP reclaim, squeeze breakout, relative strength vs benchmark, and multi-timeframe confirmations.
                </div>
              )}

              {tab === 'Options' && (
                <div className="small">
                  Mock options panel (to be connected later):
                  Most-active strike, OI/Volume/ΔOI, IV, Greeks, and spread strategies (Bull Call Spread, Bear Put Spread, Iron Condor).
                </div>
              )}

              {tab === 'Quarterly Results' && (
                <div className="small">
                  Mock quarterly results panel (to be connected later):
                  last 4 quarters table + upcoming results calendar + earnings day volatility alert.
                </div>
              )}

              {tab === 'Custom Indicator Request' && (
                <div className="small">
                  Request a customised indicator (mutual consent):
                  specify market, timeframe, entry/exit rules, alerts required, and notes. In Mock mode, this will be stored locally.
                </div>
              )}

              <div className="footerNote">
                Internal testing build goal: fast loading, stable UI, skip login.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
