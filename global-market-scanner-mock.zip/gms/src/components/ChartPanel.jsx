import React, { useEffect, useMemo, useRef } from 'react'
import { createChart } from 'lightweight-charts'
import { makeMockCandles } from '../mock/candles'

export default function ChartPanel({ seedPrice = 1500 }) {
  const ref = useRef(null)

  const data = useMemo(() => makeMockCandles(180, seedPrice), [seedPrice])

  useEffect(() => {
    if (!ref.current) return

    const chart = createChart(ref.current, {
      height: 360,
      layout: {
        background: { color: 'rgba(0,0,0,0)' },
        textColor: '#EAF0FF'
      },
      grid: {
        vertLines: { color: 'rgba(217,180,92,0.08)' },
        horzLines: { color: 'rgba(217,180,92,0.08)' }
      },
      timeScale: {
        borderColor: 'rgba(217,180,92,0.18)'
      },
      rightPriceScale: {
        borderColor: 'rgba(217,180,92,0.18)'
      },
      crosshair: {
        vertLine: { color: 'rgba(243,211,140,0.35)' },
        horzLine: { color: 'rgba(243,211,140,0.35)' }
      }
    })

    const series = chart.addCandlestickSeries({
      upColor: '#2AE38E',
      downColor: '#FF4D6D',
      borderUpColor: '#2AE38E',
      borderDownColor: '#FF4D6D',
      wickUpColor: '#2AE38E',
      wickDownColor: '#FF4D6D'
    })

    series.setData(data)
    chart.timeScale().fitContent()

    const onResize = () => {
      chart.applyOptions({ width: ref.current.clientWidth })
    }
    onResize()
    window.addEventListener('resize', onResize)

    return () => {
      window.removeEventListener('resize', onResize)
      chart.remove()
    }
  }, [data])

  return (
    <div style={{ width: '100%', minHeight: 360 }} ref={ref} />
  )
}
