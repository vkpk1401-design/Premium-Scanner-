// Lightweight Charts expects time in seconds.
export function makeMockCandles(days = 120, startPrice = 1500) {
  const candles = []
  let price = startPrice
  const now = Math.floor(Date.now() / 1000)
  const day = 24 * 60 * 60

  for (let i = days; i >= 0; i--) {
    const t = now - i * day
    const drift = (Math.sin(i / 9) * 6) + (Math.random() - 0.5) * 20
    const open = price
    const close = Math.max(10, price + drift)
    const high = Math.max(open, close) + Math.random() * 18
    const low = Math.min(open, close) - Math.random() * 18
    const volume = Math.floor(100000 + Math.random() * 900000)

    candles.push({ time: t, open, high, low, close, volume })
    price = close
  }
  return candles
}
