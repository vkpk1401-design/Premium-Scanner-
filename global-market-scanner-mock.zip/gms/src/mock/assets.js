export const mockAssets = [
  {
    key: 'NSE:RELIANCE',
    symbol: 'RELIANCE',
    name: 'Reliance Industries',
    price: 2921.35,
    changePct: 1.24,
    beta: 1.35,
    signal: { direction: 'BULL', label: 'Breakout', confidence: 82, reasons: ['20D High Break', 'Volume Spike', 'EMA20>EMA50', 'RSI>60', 'Beta 1.35'] }
  },
  {
    key: 'NSE:TCS',
    symbol: 'TCS',
    name: 'Tata Consultancy Services',
    price: 4022.1,
    changePct: -0.62,
    beta: 0.92,
    signal: { direction: 'BEAR', label: 'Breakdown', confidence: 76, reasons: ['20D Low Break', 'RSI<40', 'VWAP Reject', 'Weak Breadth'] }
  },
  {
    key: 'NSE:INFY',
    symbol: 'INFY',
    name: 'Infosys',
    price: 1744.9,
    changePct: 0.34,
    beta: 1.08,
    signal: { direction: 'BULL', label: 'Breakout', confidence: 71, reasons: ['Bollinger Squeeze', 'RVol>1.8', 'MACD Upturn'] }
  },
  {
    key: 'NSE:HDFCBANK',
    symbol: 'HDFCBANK',
    name: 'HDFC Bank',
    price: 1546.2,
    changePct: -1.08,
    beta: 1.12,
    signal: { direction: 'BEAR', label: 'Breakdown', confidence: 68, reasons: ['Support Break', 'Delivery Spike', 'Trend Weak'] }
  }
]
